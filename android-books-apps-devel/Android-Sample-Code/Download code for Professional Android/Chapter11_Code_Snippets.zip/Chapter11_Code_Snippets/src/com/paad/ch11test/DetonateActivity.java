/**
 * Empty stub class to support permission example. 
 */

package com.paad.ch11test;

import android.app.Activity;
import android.os.Bundle;

public class DetonateActivity extends Activity {
  
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
  }
}