/**
 * Demonstrate the compound controls created in
 * {@link ClearbleEditText} and {@link ClearableEditTextInCode}.
 */

package com.paad.chapter4;

import android.app.Activity;
import android.os.Bundle;

public class A5CompoundControls extends Activity {

  @Override
	public void onCreate(Bundle icicle) {
	  super.onCreate(icicle);
	  setContentView(R.layout.compound_view_activity);
	}
	
}