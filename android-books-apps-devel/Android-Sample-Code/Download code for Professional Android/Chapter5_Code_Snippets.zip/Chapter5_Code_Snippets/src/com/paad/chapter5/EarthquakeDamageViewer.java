package com.paad.chapter5;

import android.app.Activity;
import android.os.Bundle;

/** Stub Activity to demonstrate implicit Intents */
public class EarthquakeDamageViewer extends Activity {
		
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.main);
    }
}